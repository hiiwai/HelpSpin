"""The main canvas: drop spectra straight onto it and see them.

Deliberately simple, replacing the earlier layout-first flow (define a figure
with N slots, then fill the slots). Here you just drag one or more datasets
from the browser onto the canvas and they are loaded and drawn. Arrangement
(overlay vs stacked) is a control you flip afterwards, not a decision you have
to make up front.

Loading happens on a worker thread: reading processed data off a network share
is slow enough to freeze the GUI if done inline. Each spectrum is drawn as it
arrives, so dropping several does not block on the slowest one.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtCore import QObject, QRunnable, Qt, QThreadPool, Signal
from PySide6.QtWidgets import QVBoxLayout, QWidget

from ..domain.project import DEFAULT_PALETTE as PALETTE
from .dataset_model import MIME_DATASET

# Okabe-Ito is already the domain palette; reuse it so on-screen colours match
# whatever an eventual export produces.
_FALLBACK_PALETTE = [
    "#000000", "#E69F00", "#56B4E9", "#009E73",
    "#F0E442", "#0072B2", "#D55E00", "#CC79A7",
]


def _palette() -> list[str]:
    try:
        return list(PALETTE) or _FALLBACK_PALETTE
    except Exception:  # noqa: BLE001 - palette shape is not load-bearing here
        return _FALLBACK_PALETTE


@dataclass
class Trace:
    """One loaded 1D spectrum on the canvas.

    y_scale and y_offset are per-trace so a weak spectrum can be brought up to
    a strong one without touching the others -- adjusted with the scroll wheel
    over the plot, or typed exactly. line_width and color are per-trace too so
    a preference change can apply to all while still allowing overrides.
    """

    path: Path
    label: str
    ppm: np.ndarray
    intensity: np.ndarray
    color: str
    visible: bool = True
    y_scale: float = 1.0
    y_offset: float = 0.0
    line_width: float = 0.8


class _LoadSignals(QObject):
    loaded = Signal(object, object, object, str)   # path, ppm, intensity, label
    failed = Signal(object, str)                   # path, message


class _LoadTask(QRunnable):
    """Reads one spectrum off the GUI thread.

    Pure I/O plus numpy: touches no Qt model state, so it is safe on a worker.
    The result is handed back by signal and applied on the GUI thread.
    """

    def __init__(self, reader, path: Path, label: str, dimensionality: int):
        super().__init__()
        self._reader = reader
        self._path = path
        self._label = label
        self._dim = dimensionality
        self.signals = _LoadSignals()

    def run(self) -> None:
        try:
            if self._dim != 1:
                # 2D contour rendering is not implemented yet; say so plainly
                # rather than silently dropping the file.
                self.signals.failed.emit(
                    self._path, "2D display is not implemented yet"
                )
                return
            spec = self._reader.read_1d(self._path)
            ppm = np.asarray(spec.axis.ppm_scale(), dtype=np.float64)
            intensity = np.asarray(spec.real, dtype=np.float64)
            self.signals.loaded.emit(self._path, ppm, intensity, self._label)
        except Exception as exc:  # noqa: BLE001 - one bad file must not kill the drop
            self.signals.failed.emit(self._path, str(exc))


class SpectrumCanvas(QWidget):
    """A matplotlib canvas that accepts dataset drops and plots them.

    Public surface kept small on purpose: drop things on it, call
    set_arrangement / set_ppm_range / clear. No figure-layout model, no slots.
    """

    spectrumAdded = Signal(str)      # label
    loadFailed = Signal(str, str)    # path, message
    tracesChanged = Signal()

    ARRANGEMENT_OVERLAY = "overlay"
    ARRANGEMENT_STACKED = "stacked"

    def __init__(self, reader=None, pool: QThreadPool | None = None, parent=None):
        super().__init__(parent)
        if reader is None:
            from ..infrastructure.nmrglue_reader import NmrglueReader

            reader = NmrglueReader()
        self._reader = reader
        self._pool = pool or QThreadPool.globalInstance()
        self._traces: list[Trace] = []
        self._arrangement = self.ARRANGEMENT_OVERLAY
        self._ppm_range: tuple[float, float] | None = None
        self._inflight: set = set()
        self._selected_index: int | None = None
        self._default_line_width = 0.8
        self._palette_override: list[str] | None = None

        self._figure = Figure(figsize=(6, 4), tight_layout=False)
        self._canvas = FigureCanvasQTAgg(self._figure)
        self._axes = self._figure.add_subplot(111)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._canvas)

        self.setAcceptDrops(True)
        # Scroll wheel over the plot scales the SELECTED trace vertically.
        self._canvas.setFocusPolicy(Qt.WheelFocus)
        self._canvas.wheelEvent = self._on_canvas_wheel
        self._redraw()

    # -- public state --------------------------------------------------------

    @property
    def traces(self) -> list[Trace]:
        return list(self._traces)

    def arrangement(self) -> str:
        return self._arrangement

    def set_arrangement(self, arrangement: str) -> None:
        if arrangement not in (self.ARRANGEMENT_OVERLAY, self.ARRANGEMENT_STACKED):
            return
        self._arrangement = arrangement
        self._redraw()

    def set_ppm_range(self, left: float, right: float) -> None:
        """ppm axes descend, so left must be the HIGHER value."""
        if left <= right:
            return
        self._ppm_range = (left, right)
        self._redraw()

    def full_range(self) -> None:
        """Union of every loaded trace's ppm span (not the intersection) --
        show everything rather than only the overlap."""
        self._ppm_range = None
        self._redraw()

    def ppm_bounds(self) -> tuple[float, float] | None:
        """Union of every visible trace's ppm span, or None if nothing loaded.

        Union rather than intersection: the range control should be able to
        show everything that exists, not only the overlap.
        """
        visible = [t for t in self._traces if t.visible]
        if not visible:
            return None
        left = max(float(np.nanmax(t.ppm)) for t in visible)
        right = min(float(np.nanmin(t.ppm)) for t in visible)
        return (left, right)

    def clear(self) -> None:
        """Reset the canvas completely -- traces, selection, and ppm range.

        A true "start over", not just removing the lines: leaving a stale ppm
        range or selection behind after clearing is what makes the next drop
        appear on a nonsensical axis.
        """
        self._traces.clear()
        self._ppm_range = None
        self._selected_index = None
        self._redraw()
        self.tracesChanged.emit()

    # -- selection and per-trace vertical scaling ----------------------------

    def selected_index(self) -> int | None:
        return self._selected_index

    def select_trace(self, index: int | None) -> None:
        """Select which trace the wheel / y-scale controls act on.

        None means 'nothing selected'; out-of-range indexes are ignored rather
        than raising, since a selection can outlive the trace it referred to.
        """
        if index is None:
            self._selected_index = None
        elif 0 <= index < len(self._traces):
            self._selected_index = index
        else:
            return
        self._redraw()
        self.tracesChanged.emit()

    def selected_trace(self) -> Trace | None:
        if self._selected_index is None:
            return None
        if not (0 <= self._selected_index < len(self._traces)):
            return None
        return self._traces[self._selected_index]

    def set_y_scale(self, index: int, scale: float) -> None:
        """Set one trace's vertical scale. Non-positive values are refused --
        a zero or negative scale would flatten or invert the spectrum, which
        is never what a scale control is meant to do."""
        if not (0 <= index < len(self._traces)):
            return
        if scale <= 0 or not np.isfinite(scale):
            return
        self._traces[index].y_scale = float(scale)
        self._redraw()
        self.tracesChanged.emit()

    def nudge_y_scale(self, index: int, factor: float) -> None:
        """Multiply a trace's scale (wheel steps). Clamped to a sane range so
        a fast scroll cannot drive it to zero or to a value that overflows."""
        if not (0 <= index < len(self._traces)):
            return
        current = self._traces[index].y_scale
        new = current * float(factor)
        new = max(1e-6, min(new, 1e9))
        self.set_y_scale(index, new)

    def set_y_offset(self, index: int, offset: float) -> None:
        if not (0 <= index < len(self._traces)):
            return
        if not np.isfinite(offset):
            return
        self._traces[index].y_offset = float(offset)
        self._redraw()
        self.tracesChanged.emit()

    def nudge_y_offset(self, index: int, delta: float) -> None:
        if not (0 <= index < len(self._traces)):
            return
        self.set_y_offset(index, self._traces[index].y_offset + float(delta))

    def _on_canvas_wheel(self, event) -> None:
        """Wheel over the plot scales the selected trace vertically.

        With nothing selected the wheel does nothing rather than silently
        scaling an arbitrary trace -- guessing which spectrum the user meant
        would be worse than requiring a click first.
        """
        index = self._selected_index
        if index is None:
            event.ignore()
            return
        delta = event.angleDelta().y()
        if delta == 0:
            event.ignore()
            return
        # ~10% per notch, direction following the scroll.
        factor = 1.1 if delta > 0 else (1.0 / 1.1)
        self.nudge_y_scale(index, factor)
        event.accept()

    # -- appearance preferences ---------------------------------------------

    def set_default_line_width(self, width: float) -> None:
        """Applies to every trace, including ones already drawn."""
        if width <= 0 or not np.isfinite(width):
            return
        self._default_line_width = float(width)
        for trace in self._traces:
            trace.line_width = float(width)
        self._redraw()

    def default_line_width(self) -> float:
        return self._default_line_width

    def set_trace_line_width(self, index: int, width: float) -> None:
        if not (0 <= index < len(self._traces)):
            return
        if width <= 0 or not np.isfinite(width):
            return
        self._traces[index].line_width = float(width)
        self._redraw()

    def set_trace_color(self, index: int, color: str) -> None:
        if not (0 <= index < len(self._traces)):
            return
        if not color:
            return
        self._traces[index].color = color
        self._redraw()
        self.tracesChanged.emit()

    def set_palette(self, colors: list[str]) -> None:
        """Replace the colour cycle and recolour existing traces in order."""
        if not colors:
            return
        self._palette_override = list(colors)
        for i, trace in enumerate(self._traces):
            trace.color = colors[i % len(colors)]
        self._redraw()
        self.tracesChanged.emit()

    def _active_palette(self) -> list[str]:
        return self._palette_override or _palette()

    def set_trace_visible(self, index: int, visible: bool) -> None:
        if not (0 <= index < len(self._traces)):
            return
        self._traces[index].visible = bool(visible)
        self._redraw()
        self.tracesChanged.emit()

    def remove_trace(self, path: Path) -> None:
        before = len(self._traces)
        self._traces = [t for t in self._traces if t.path != Path(path)]
        if len(self._traces) != before:
            self._redraw()
            self.tracesChanged.emit()

    # -- loading -------------------------------------------------------------

    def add_dataset(self, path, label: str, dimensionality: int = 1) -> None:
        """Queue one dataset for loading and drawing."""
        path = Path(path)
        if any(t.path == path for t in self._traces):
            return   # already shown; dropping twice is a no-op, not a duplicate
        task = _LoadTask(self._reader, path, label, dimensionality)
        task.signals.loaded.connect(self._on_loaded)
        task.signals.failed.connect(self._on_failed)
        # Hold a reference: QThreadPool does not keep the Python object alive,
        # and losing it mid-flight would silently discard the result.
        self._inflight.add(task)
        self._pool.start(task)

    def _on_loaded(self, path, ppm, intensity, label: str) -> None:
        path = Path(path)
        self._inflight = {t for t in self._inflight if t._path != path}
        if any(t.path == path for t in self._traces):
            return
        palette = self._active_palette()
        color = palette[len(self._traces) % len(palette)]
        self._traces.append(
            Trace(
                path=path, label=label, ppm=ppm, intensity=intensity,
                color=color, line_width=self._default_line_width,
            )
        )
        # First spectrum dropped becomes the selection, so the wheel and
        # y-scale controls work immediately without an extra click.
        if self._selected_index is None:
            self._selected_index = len(self._traces) - 1
        self._redraw()
        self.spectrumAdded.emit(label)
        self.tracesChanged.emit()

    def _on_failed(self, path, message: str) -> None:
        path = Path(path)
        self._inflight = {t for t in self._inflight if t._path != path}
        self.loadFailed.emit(str(path), message)

    # -- drawing -------------------------------------------------------------

    def _redraw(self) -> None:
        self._axes.clear()

        # Guard on VISIBLE traces, not merely on any traces existing: with
        # spectra loaded but all of them unchecked, the drawing code below has
        # nothing to take a max() over and previously raised ValueError,
        # crashing the redraw. Both "nothing loaded" and "all hidden" show the
        # empty state.
        visible_traces = [t for t in self._traces if t.visible]
        if not visible_traces:
            self._axes.set_xticks([])
            self._axes.set_yticks([])
            for spine in self._axes.spines.values():
                spine.set_visible(False)
            self._axes.text(
                0.5, 0.5,
                "Drag spectra here" if not self._traces
                else "All spectra hidden",
                ha="center", va="center", fontsize=13, color="#999999",
                transform=self._axes.transAxes,
            )
            self._canvas.draw_idle()
            return

        for spine in self._axes.spines.values():
            spine.set_visible(True)

        visible = visible_traces
        offset_step = 0.0
        if self._arrangement == self.ARRANGEMENT_STACKED and visible:
            # Stack by a fraction of the tallest trace so spacing is stable
            # regardless of absolute intensity.
            # Measure the SCALED span: if a trace has been scaled up, the
            # stack spacing must grow with it or it overlaps its neighbour.
            tallest = max(
                (float(np.nanmax(t.intensity)) - float(np.nanmin(t.intensity)))
                * t.y_scale
                for t in visible
            )
            offset_step = tallest * 1.05 if tallest > 0 else 1.0

        selected = self.selected_trace()
        for i, trace in enumerate(visible):
            # Per-trace vertical scale and offset, then the stacking offset.
            y = (trace.intensity * trace.y_scale) + trace.y_offset + (offset_step * i)
            width = trace.line_width
            if selected is not None and trace is selected and len(visible) > 1:
                width = width * 1.9   # make the selected trace obvious
            self._axes.plot(
                trace.ppm, y, color=trace.color, linewidth=width,
                label=trace.label,
            )

        # ppm axes are conventionally DESCENDING (high ppm on the left).
        if self._ppm_range is not None:
            left, right = self._ppm_range
        else:
            left = max(float(np.nanmax(t.ppm)) for t in visible)
            right = min(float(np.nanmin(t.ppm)) for t in visible)
        self._axes.set_xlim(left, right)

        nucleus_hint = ""
        self._axes.set_xlabel(f"{nucleus_hint}ppm".strip())
        if self._arrangement == self.ARRANGEMENT_STACKED:
            self._axes.set_yticks([])
        if len(visible) > 1:
            self._axes.legend(loc="upper right", fontsize=8, frameon=False)

        self._figure.tight_layout()
        self._canvas.draw_idle()

    # -- drag and drop -------------------------------------------------------
    #
    # dragEnterEvent MUST call acceptProposedAction() or dropEvent never fires
    # -- the single most common Qt drag-and-drop mistake.

    def dragEnterEvent(self, event) -> None:
        if event.mimeData().hasFormat(MIME_DATASET):
            event.acceptProposedAction()

    def dragMoveEvent(self, event) -> None:
        if event.mimeData().hasFormat(MIME_DATASET):
            event.acceptProposedAction()

    def dropEvent(self, event) -> None:
        if self.handle_mime_data(event.mimeData()):
            event.acceptProposedAction()

    def handle_mime_data(self, mime) -> bool:
        """Decode a dataset payload and queue every entry.

        Separate from dropEvent so tests can exercise it with a plain
        QMimeData, without constructing QDropEvent objects whose signature
        varies between Qt versions.
        """
        if not mime.hasFormat(MIME_DATASET):
            return False
        try:
            payload = json.loads(bytes(mime.data(MIME_DATASET)).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return False
        if not payload:
            return False
        for item in payload:
            self.add_dataset(
                item["path"],
                item.get("label") or Path(item["path"]).name,
                int(item.get("dimensionality", 1)),
            )
        return True
